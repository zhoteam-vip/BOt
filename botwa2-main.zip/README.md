<h1 align="center">GSS BOTWA-MD</h1>
 
<p align="center">  
  <a href="https://youtu.be/WcA7GZuaN0A">
   <img alt="botgsswa" height="300" src="https://github.com/Ethix-Xsid.png">
    
<p align="center">
<a href="https://github.com/Ethix-Xsid"><img title="Author" src="https://img.shields.io/badge/GSS-BOTWA-black?style=for-the-badge&logo=WhatsApp"></a>


 
<p align="center"> Introducing GSS BOTWA MD, It is designed to bring a whole new level of excitement to your boring WhatsApp use. </p>


   <p align="center">
  <a aria-label="GSS BOTWA MD is free to use" href="https://youtube.com/@mhmodsofc" target="_blank">
    <img alt="MH MODS OFC Yt" src="https://img.shields.io/youtube/channel/subscribers/UCWHA-PreVSVaYhDTAiUipCA" target="_blank" />
  </a>

</p>
<p align="center"><img src="https://profile-counter.glitch.me/{chhaseeb47}/count.svg" alt="chhaseeb47 :: Visitor's Count" /></p>



  <p align="center">
<a href="https://whatsapp.com/channel/0029Va8SjGU1noyxsYBA2K2e"><img src="https://img.shields.io/badge/Connect on WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"></a>
<a href="https://www.youtube.com/channel/UCWHA-PreVSVaYhDTAiUipCA"><img src="https://img.shields.io/badge/Subcribe On Youtube-E4405F?style=for-the-badge&logo=youtube&logoColor=white"></a>
<a href="https://whatsapp.com/channel/0029VaFNrVHBfxoBuY2TzH2w"><img src="https://img.shields.io/badge/Join WhatsApp Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"></a>
   
<p align="center">
<a href="https://github.com/Ethix-Xsid/followers"><img title="Followers" src="https://img.shields.io/github/followers/Ethix-Xsid?color=red&style=flat-square"></a>
<a href="https://github.com/Ethix-Xsid/Ethix-Xsid2/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Ethix-Xsid/Ethix-Xsid2?color=blue&style=flat-square"></a>
<a href="https://github.com/Ethix-Xsid/Ethix-Xsid2/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Ethix-Xsid/Ethix-Xsid2?color=red&style=flat-square"></a>
<a href="https://github.com/Ethix-Xsid/Ethix-Xsid2/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Ethix-Xsid/Ethix-Xsid2?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/Ethix-Xsid/Ethix-Xsid2"><img title="Open Source" src="https://img.shields.io/badge/Author-ETHIX SID X %20HASEEB-red?v=103"></a>
<a href="https://github.com/Ethix-Xsid/Ethix-Xsid2/"><img title="Size" src="https://img.shields.io/github/repo-size/Ethix-Xsid/Ethix-Xsid2?style=flat-square&color=green"></a>
<a href="https://github.com/Ethix-Xsid/Ethix-Xsid2/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;
</p>
<p align='center'>
</p>

---
### 1. FORK THIS REPO
<a href='https://github.com/Ethix-Xsid/Ethix-Xsid2/fork' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/Fork This Repo-black?style=for-the-badge&logo=git&logoColor=white'/></a>


### 2. GET SESSION VIA PAIR CODE
<a href='https://replit.com/@MHMODS/GSS-BOT-WA-PAIR-1?v=1' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/Click here to get your credit js-black?style=for-the-badge&logo=opencv&logoColor=white'/></a>

## Your Bot Cannot run without this.

```
mongodb+srv://mohsin:mohsin@cluster0.iauaztt.mongodb.net/?retryWrites=true&w=majority
```
<a href='https://youtu.be/_Yqtsho9eI0?si=_ezalTW5QiTI-0w2' target="_blank"><img alt='Mongodb Url Tutorial' src='https://img.shields.io/badge/-Mongodb Url Tutorial-green?style=for-the-badge&logo=mongodb&logoColor=darkgreen'/></a>



#### DEPLOY TO HEROKU 

1. If You don't have a account in Heroku. Create a account.
    <br>
<a href='https://signup.heroku.com/' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=heroku&logoColor=white'/></a>

2. Now Deploy
    <br>
<a href='https://heroku.com/deploy' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=heroku&logoColor=white'/></a>

3. How To Deploy video Tutorial.
     <br>
          <a href='https://youtu.be/NbREC9DTQcA?si=bamV9UTA5nXGwDDD' target="_blank"><img alt='Heroku Deploy Tutorial' src='https://img.shields.io/badge/-Heroku Deploy Tutorial-red?style=for-the-badge&logo=youtube&logoColor=white'/></a>

#### DEPLOY TO CODESPACE

1. If You don't have a account in Codespace. Create a account.
    <br>
<a href='https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Fcodespaces' target="_blank"><img alt='Codespaces' src='https://img.shields.io/badge/CREATE-h?color=black&style=for-the-badge&logo=visualstudiocode' width="96.35" height="28"/></a></p>

2. Now Deploy
    <br>
<a href='https://github.com/codespaces/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=black&style=for-the-badge&logo=visualstudiocode' width="96.35" height="28"/></a></p>


#### DEPLOY TO RAILWAY

1. If You don't have a account in Railway. Create a account.
    <br>
<a href='https://railway.app/login' target="_blank"><img alt='Railway' src='https://img.shields.io/badge/CREATE-h?color=black&style=for-the-badge&logo=railway' width="96.35" height="28"/></a></p>

2. Now Deploy
    <br>
<a href='https://railway.app/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=black&style=for-the-badge&logo=railway' width="96.35" height="28"/></a></p>

#### DEPLOY TO MONGENIUS

1. If You don't have a account in Mongenius. Create a account.
    <br>
<a href='https://studio.mogenius.com/user/registration' target="_blank"><img alt='Mongenius' src='https://img.shields.io/badge/CREATE-h?color=black&style=for-the-badge&logo=genius' width="96.35" height="28"/></a></p>

2. Now Deploy
    <br>
<a href='https://railway.app/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=black&style=for-the-badge&logo=genius' width="96.35" height="28"/></a></p>


#### DEPLOY TO REPLIT

1. If You don't have a account in Replit. Create a account.
    <br>
<a href='https://replit.com/' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=replit&logoColor=white'/></a>

2. Now Deploy
    <br>
<a href='https://replit.com/github/Ethix-Xsid/Ethix-Xsid2' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Deploy-black?style=for-the-badge&logo=replit&logoColor=white'/></a>

---

## `DEVELOPERS`
<div align="left">
  <a href="[https://github.com/Ethix-Xsid]"><img src="https://github.com/Ethix-Xsid.png" width="150" height="200" alt="Ash"/></a>
<a href="[https://github.com/chhaseeb47]"><img src="https://github.com/chhaseeb47.png" width="200" height="200" alt="Ash"/></a>
 </div>
<br>
<h4 align="left">

| [SIDHARTH ](https://github.com/Ethix-Xsid) |
| Owner, Developer, Bug Fixer, Maintainer, updates|

| [ CH HASEEB ](https://github.com/chhaseeb47) |
| CO.Devloper |



  </br> 
<h4 align="left">

  
***Tap On Logo To Subscribe MY YouTube Channel***
</p>
 <p align="left">
  <a href="https://www.youtube.com/@SinghaniyaTech0744?sub_confirmation=1">
    <img alt=Support height="70" src="https://telegra.ph/file/eb6347e2764939fbbd35d.png"> 
  </p>
    
 ***Tap On Logo To Contat Me***


 <p align="left">
<a href="mailto:bsid4961@gmail.com"><img title="Author" src="https://img.shields.io/badge/GMAIL-ME-black?style=for-the-badge&logo=Gmail"></a>
 <p align="left"> 
  <a href="https://wa.me/919142294671?text=Hi+sid+Sir...+I+need+some+help+in+Gss_Botwa"><img title="Author" src="https://img.shields.io/badge/WHATSAPP-ME-red?style=for-the-badge&logo=WhatsApp"></a>
  
   

 



</br>


<h2 align="center">  Reminder
</h2>
   
- This bot is not made by `WhatsApp Inc.` So misusing the bot might `ban` your `WhatsApp account!`(Though your WhatsApp account can be unbanned only once.)
- I am not responsible for banning your account.
- Use at your own risk by keeping this warning in mind.

---

</p>
<h1 align="center"> Keep Supporting
</h1>

 <br><br>
