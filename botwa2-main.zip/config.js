const fs = require('fs');
const chalk = require('chalk');


// Other
global.link = 'https://whatsapp.com/channel/0029VaWJMi3GehEE9e1YsI1S'
global.linkGroup = 'https://chat.whatsapp.com/E3PWxdvLc7ZCp1ExOCkEGp'

global.apikey = 'bf2d2cf29b3edc604b447983';
global.ownername = "الجن أبوشتا";
global.owner = ['33656675212'];
global.premium = ['33656675212'];
global.packname = "رقية 𝚋𝚢";
global.author = "ABo Chta";
global.sessionName = 'session';
global.prefa = [".", "!", "/", "?"];
global.typemenu = "v1"
global.menuType = "2"
global.autoswview = true
global.autoread = false
global.available = false
global.autoTyping = false
global.autoRecord = false
global.autoreact = false
global.onlygroup = false
global.onlypc = false
global.welcome = true
global.autoBlock = true
 
/*REPLY MESSAGE*/
global.mess = {
    banned: '`You are *Banned* fron using commands!`',
    bangc: '`This Group is *Banned* from using Commands!`',
    success: '`✓ Success`',
    admin: '`This feature is only for group admins`',
    botAdmin: '`I am not an admin!`',
    owner: '`You are not my owner`',
    group: '`You can use this command only in groups ❌`',
    private: '`Feature is used only for private chats!`',
    bot: '`Bot number user special features`',
    wait: '*Processing Your request*',
    endLimit: '`Your daily limit has expired, the limit will be reset every 12 hours`',
};

global.limitawal = {
    premium: 'Infinity',
    free: 10
};
